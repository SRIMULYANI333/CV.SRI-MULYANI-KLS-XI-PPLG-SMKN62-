-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 21, 2025 at 02:54 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `srimulyani`
--

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `username` varchar(5000) NOT NULL,
  `pasword` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`username`, `pasword`) VALUES
('sri', 'mul');

-- --------------------------------------------------------

--
-- Table structure for table `sri`
--

CREATE TABLE `sri` (
  `no` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `jenis_kelamin` mediumtext NOT NULL,
  `kelas` text NOT NULL,
  `umur` text NOT NULL,
  `no_hp` varchar(100) NOT NULL,
  `tanggal_lahir` text NOT NULL,
  `pengalaman` text NOT NULL,
  `hobi` varchar(5000) NOT NULL,
  `alamat` varchar(5000) NOT NULL,
  `skill` varchar(5000) NOT NULL,
  `pendidikan` text NOT NULL,
  `pekerjaan` text NOT NULL,
  `sifat_saya` mediumtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sri`
--

INSERT INTO `sri` (`no`, `nama`, `jenis_kelamin`, `kelas`, `umur`, `no_hp`, `tanggal_lahir`, `pengalaman`, `hobi`, `alamat`, `skill`, `pendidikan`, `pekerjaan`, `sifat_saya`) VALUES
(12, 'SRI MULYANI', 'PEREMPUAN', 'XI PPLG 2', '16 TAHUN', '087797825269', '06-06-2008', 'MAIN ML', 'TIDUR', 'PERUMAHAN MAWAR PUTIH', 'TIDUR', '1.SD 79 KOTA JAMBI\r\n2.SMP 08 MUARA JAMBI\r\n3.SMK 02 KOTA JAMBI', 'MASIH SEKOLAH', 'SUKA TIDUR');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `username` varchar(5000) NOT NULL,
  `pasword` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`username`, `pasword`) VALUES
('sri', 'mul'),
('mul', 'cli');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `sri`
--
ALTER TABLE `sri`
  ADD PRIMARY KEY (`no`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `sri`
--
ALTER TABLE `sri`
  MODIFY `no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
